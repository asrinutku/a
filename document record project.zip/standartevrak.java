/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evrakproje;

/**
 *
 * @author ENTEGRE
 */
public class standartevrak {
    private int dosyano;
    private String yazıcı;
    private String alıcı;
    private String konu;
    private int tarih;
    private int önemseviyesi;
    
    public standartevrak(int dosyano , String konu , String  yazıcı , String alıcı, int tarih , int önemseviyesi){
        this.dosyano = dosyano;
        this.konu = konu;
        this.yazıcı =  yazıcı;
        this.alıcı = alıcı;
        this.tarih = tarih;
        this.önemseviyesi = önemseviyesi;
    }

    public int getDosyano() {
        return dosyano;
    }

    public String getYazıcı() {
        return yazıcı;
    }

    public String getAlıcı() {
        return alıcı;
    }

    public String getKonu() {
        return konu;
    }

    public int getTarih() {
        return tarih;
    }

    public int getönemseviyesi() {
        return önemseviyesi;
    }
    
}

