/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evrakproje;

/**
 *
 * @author ENTEGRE
 */
public class medikalevrak {
    public int dosyano;
    public String hastaadı;
    public String doktoradı;
    public int tedavisuresi;
    public int tarih;
    public int onemderecesi;
    
    medikalevrak(int dosyano , String hastaadı , String doktoradı, int tedavisuresi, int tarih , int onemderecesi){
        this.dosyano = dosyano;
        this.hastaadı = hastaadı;
        this.doktoradı = doktoradı;
        this.tedavisuresi = tedavisuresi;  
        this.tarih = tarih;
        this.onemderecesi = onemderecesi;
    }

    public int getDosyano() {
        return dosyano;
    }

    public String getHastaadı() {
        return hastaadı;
    }

    public String getDoktoradı() {
        return doktoradı;
    }

    public int getTedavisuresi() {
        return tedavisuresi;
    }
 
    public int getTarih(){
        return tarih;
    }
    
    public int getOnemderecesi() {
        return onemderecesi;
    }
    
    
    
}
