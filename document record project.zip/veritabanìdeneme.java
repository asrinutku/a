

package evrakproje;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;



public class veritabanıdeneme {
    
    private String kullaniciadi = "root";
    private String parola = "";  
    private String dbismi = "evrakkayit";
    private String host = "localhost";
    private int port = 3306; 
    static Connection con = null;
    static Statement stat = null;
    
    
    public veritabanıdeneme(){
        // jdbc:mysql://localhost:3306/demo
        String url = "jdbc:mysql://" + host + ":" + port + "/" + dbismi ;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("DRİVER VAR");
        } catch (ClassNotFoundException ex) {
            System.out.println("DRİVER YOK");
        }
        
        try {
        con = DriverManager.getConnection(url , kullaniciadi, parola);
        stat = (Statement) con.createStatement();
        
            System.out.println("BAGLANTI BASARILI");
        } catch (SQLException ex){
            System.out.println("BAGLANTI BASARISIZ");
        }
    }
    
    public int ekle(String sqlsorgu){
        try {
            stat.executeUpdate(sqlsorgu);
            System.out.println("BASARILI EKLEME");
            return 1;
        } catch (SQLException ex) {
            System.out.println("BASARİSİZ EKLEME");
            Logger.getLogger(veritabanıdeneme.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
    
    
    public static void main(String[] args){
        veritabanıdeneme vt = new veritabanıdeneme();
    }
   
}



