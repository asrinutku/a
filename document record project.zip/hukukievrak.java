/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evrakproje;

/**
 *
 * @author ENTEGRE
 */
public class hukukievrak {
    public int dosyano;
    public String suclununadi;
    public int cezasuresi;
    
    public String suc;
    public int tarih;
    public int onemderesi;

    public hukukievrak(int dosyano, String suclununadi, int cezasuresi,  String suc, int tarih, int onemderesi) {
        this.dosyano = dosyano;
        this.suclununadi = suclununadi;
        this.cezasuresi = cezasuresi;
        
        this.suc = suc;
        this.tarih = tarih;
        this.onemderesi = onemderesi;
    }
    
    public int getDosyano() {
        return dosyano;
    }

    public String getSuclununadi() {
        return suclununadi;
    }

    public int getCezasuresi() {
        return cezasuresi;
    }

    

    public String getSuc() {
        return suc;
    }

    public int getTarih() {
        return tarih;
    }

    public int getOnemderecesi() {
        return onemderesi;
    }
    
    
    
}
